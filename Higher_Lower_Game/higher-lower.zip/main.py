# import logo and vs from art
from art import logo
from art import vs
from game_data import data
from random import randint
from replit import clear

def pick(second_choice):
  if second_choice == 0:
    first_choice = randint(0,49)
  else:
    first_choice = second_choice
  
  isEqual = True
  while(isEqual):
    second_choice = randint(0,49)
    if first_choice != second_choice:
      isEqual = False
  return first_choice, second_choice

def compareAB(choice1, choice2):
  if data[choice1]['follower_count'] > data[choice2]['follower_count']:
    return 'A'
  else:
    return 'B'

def start_game():
  print(logo)
  B = 0
  [A,B] = pick(B)
  print(f'Compare A: {data[A]["name"]}, {data[A]["description"]}, {data[A]["country"]}')
  print(vs)
  print(f'Compare B: {data[B]["name"]}, {data[B]["description"]}, {data[B]["country"]}')
  right_decision = compareAB(A,B)
  answer = input("Who has more follwers? Type 'A' or 'B': ")
  if answer == right_decision:
    return 1, B
  else:
    return 0, B

def continue_game(B,score):
  keep_playing = True
  while (keep_playing):
    print(logo)
    print(f"You're right! Your current score: {score}.")
    [A,B] = pick(B)
    print(f'Compare A: {data[A]["name"]}, {data[A]["description"]}, {data[A]["country"]}')
    print(vs)
    print(f'Compare B: {data[B]["name"]}, {data[B]["description"]}, {data[B]["country"]}')
    right_decision = compareAB(A,B)
    answer = input("Who has more follwers? Type 'A' or 'B': ")
    if answer == right_decision:
      score += 1
      clear()
    else:
      clear()
      return score

new_game = True
while(new_game):
  clear()
  [keep_playing, B] = start_game()
  if keep_playing == 1:
    clear()
    final_score = continue_game(B,1)
  else:
    clear()
    final_score = keep_playing
  print(logo)
  print(f"Sorry, that's wrong. Final score: {final_score}")
  again = input("Do you want to play a new game? 'yes' or 'no': ")
  if again == 'no':
    new_game = False 

  
# generate a random num. by importing randint from random#
# import the game data 
# create a function that picks two random picks but different with an input of the first choice and the input is zero if it's the first time
# take the inpute from the user 
# create a function that compares the two numbers and compares the user's input 
# create a counter 
# put the turn in a loop 
# put the game in a function