#Number Guessing Game Objectives:

# Include an ASCII art logo.
# Allow the player to submit a guess for a number between 1 and 100.
# Check user's guess against actual answer. Print "Too high." or "Too low." depending on the user's answer. 
# If they got the answer correct, show the actual answer to the player.
# Track the number of turns remaining.
# If they run out of turns, provide feedback to the player. 
# Include two different difficulty levels (e.g., 10 guesses in easy mode, only 5 guesses in hard mode).
from art import logo
from replit import clear
from random import randint
attempts_easy = 10
attempts_hard = 5

def decrease_attempts(counter):
  return counter - 1

newGame = True
while (newGame): 
  clear()
  print(logo)
  print('Welcome to the Number Gessing Game!')
  print("I'm thinking of a number between 1 and 100.")
  answer = randint(1,100)
  difficulty = input("Choose a difficulty. Type 'easy' or 'hard': ")
  
  if difficulty == 'easy':
    attempts_count = attempts_easy
  elif difficulty == 'hard':
    attempts_count = attempts_hard
  
  end = 0
  while(end == 0):      
    print(f"You have {attempts_count} attempts remaining to guess the number.")
    guess = int(input('Make a guess: '))
    if guess == answer:
      print(f'You got it! The answer was {answer}.')
      end = 1
    elif guess < answer:
      print('Too low.')
      attempts_count = decrease_attempts(attempts_count)
      if attempts_count == 0:
        print("You've run out of guesses, you lose.")
        end = 1
      else:
        print("Guess again.")

    elif guess > answer:
      print('Too high.')
      attempts_count = decrease_attempts(attempts_count)
      if attempts_count == 0:
        print("You've run out of guesses, you lose.")
        end = 1
      else:
        print("Guess again.")

  choice = input("Do you want to play a new game? 'yes' or 'no': ")
  if choice == 'yes':
    newGame = True
  elif choice == 'no':
    newGame = False
